Consent Manager Installation Instructions

1. Extract the contents of this zip file
2. Place the files in your website directory
3. Add the following code to your HTML page, inside the <head> tag:

<link rel="stylesheet" id="silktide-consent-manager-css" href="path-to-css/silktide-consent-manager.css">
<script src="path-to-js/silktide-consent-manager.js"></script>
<script>
silktideCookieBannerManager.updateCookieBannerConfig({
  background: {
    showBackground: true
  },
  cookieIcon: {
    position: "bottomLeft"
  },
  cookieTypes: [
    {
      id: "necessari",
      name: "Necessari",
      description: "<p>Questi cookie sono necessari per il corretto funzionamento di thita.it (es. gestione della sessione, sicurezza, preferenze di base). Sono sempre attivi e non richiedono il tuo consenso.</p>",
      required: true,
      onAccept: function() {
        console.log('Add logic for the required Necessari here');
      }
    },
    {
      id: "analisi",
      name: "Analisi",
      description: "<p>Questi cookie ci aiutano a capire come viene utilizzato thita.it, in forma aggregata, per migliorare contenuti e prestazioni. Usiamo Google Analytics con IP anonimizzato e senza condivisione dei dati con Google per scopi propri. Senza il tuo consenso le statistiche non verranno raccolte.</p>",
      required: false,
      onAccept: function() {
        gtag('consent', 'update', {
          analytics_storage: 'granted',
        });
        dataLayer.push({
          'event': 'consent_accepted_analisi',
        });
      },
      onReject: function() {
        gtag('consent', 'update', {
          analytics_storage: 'denied',
        });
      }
    }
  ],
  text: {
    banner: {
      description: "<p>Su thita.it utilizziamo cookie tecnici necessari al funzionamento del sito e, previo tuo consenso, cookie statistici (Google Analytics) per misurare e migliorare le prestazioni. Puoi accettare tutti i cookie, rifiutare quelli non necessari o gestire le tue preferenze. Per saperne di più consulta la <a href=\"https://thita.it/cookie-policy\" target=\"_blank\">Cookie Policy.</a></p>",
      acceptAllButtonText: "Accetta",
      acceptAllButtonAccessibleLabel: "Accetta",
      rejectNonEssentialButtonText: "Rifiuta non essenziali",
      rejectNonEssentialButtonAccessibleLabel: "Rifiuta non essenziali",
      preferencesButtonText: "Preferenze",
      preferencesButtonAccessibleLabel: "Preferenze"
    },
    preferences: {
      title: "Personalizza le tue preferenze",
      description: "<p>Qui puoi scegliere in modo dettagliato quali categorie di cookie autorizzare. I cookie tecnici sono sempre attivi perché necessari al funzionamento del sito; puoi invece abilitare o disabilitare i cookie statistici in base alle tue preferenze.</p>",
      creditLinkText: " ",
      creditLinkAccessibleLabel: " "
    }
  },
  position: {
    banner: "bottomCenter"
  }
});
</script>
